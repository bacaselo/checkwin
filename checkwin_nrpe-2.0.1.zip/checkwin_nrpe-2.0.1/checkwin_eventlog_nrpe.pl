#!/usr/bin/perl
###################################################################
# Author: Cameron Seeber
# Modified: by Bart Gillis - Bacaselo
#			in order to work with the more powerfull check_nrpe command.
# Purpose:	This is a script that allows Xymon to pull event log data from a windows machine.
#			This test is a plugin for the checkwin_nrpe script and must be sheduled on a 15 minutes base!!!!!
#			This script is using the same checkwin_nrpe.cfg configuration file
# 			BBWin only pushes the data and can not be used on networks that don't allow inbound trafic.
###################################################################
#
# This is a script that allows Xymon to pull data from a windows machine.
# Our network model only allows for connections outbound from our management network so I thought I would spend the time to write this script.
# For it to work you will need to get a copy of check_nrpe on your machine.
# This is the client that is used to speak to nsclient++ that is used in Nagios.
# When you install the Nagios package or port you should find this binary (eg its in the net-mgmt/nagios port on FreeBSD)
# NSClient++ is available at http://trac.nakednuns.org/nscp/downloads
# This script was used against version 0.3.9 but should work with newer versions.
#
# You will need a config file for it to work
# I thought about putting it all in the hosts.cfg file but it just gets to messy, and I wanted to reuse some of the common tags
# The config file should be located in $XYMONHOME/etc/checkwin/checkwin_nrpe.cfg (or you can change it below)
#
# This script forks before starting each client check.  You will also notice a sleep(1) just before the fork.  I found that in speeding up the 
# client queries I was able to affect the monitoring machines network performance and cpu to the point that simple tests like http and the like
# were taking 400-800ms to complete instead of the expected 40ms. So I delayed each test for 1 second.
# This is irrelevant as each test will still start the same time apart as you configure in the tasks.cfg file (say 1 minute) as it will 
# always delay the start of the client test however low it is in the config file.
#
# Please note that this hasn't been tested by anyone but me.
#
# Known Bugs:
# - There is one know bug in the disk check. If the free disk space goes under 1 MB the monitor goes green.
#
# I have to fix these litte bugs if I find some time
#
# VARIABLES
#
# The most of the variables in this script are declared at the top of the script.
# They are all pretty straight forward and where they mirror ones in the xymonserver.cfg file they use the same names
# I thought about bringing in the config file but I thought parsing that whole file for two variables was a little too much effort.
#
# $check_nrpe	 - location of the check_nrpe binary
# $xymonwin		 - location of the checkwin_nrpe file
# $XYMONHOME	 - location of your xymon install
# $XYMON		 - xymon binary
# $XYMONSERVERIP - ip address or hostname of the xymon server
#
#
# CONFIG FILE
#
# Format of the file will be like this
#
# xymonhostname	port	password	#   test [test] ....
#
# xymonhostname	- this is the host that you want the test recorded under. This should match one in the hosts.cfg file
# port		- This is the port that nsclient++ is listening on
# password	- This is the password set in nsclient++
# # 		- This is just a seperator much like in hosts.cfg
# test		- client|cpu|disk|memory|uptime|service|procs|files|bbwin
#==================================================================================================
# log[;file,'source1','source2','source3',...[;file,'source','source','source3',...[;file,'source1','source2','source3',...]]]
#	file:					- name of the eventlog file that needs to be monitored
#	source1,source2,...:	- event source that will be ignored in by the monitor. (must be placed between single quotes ' )
#
# This plugin will monitor the windows event log files and will display all errors and warnings that are posted for the last 15 minutes.
#
# - the test result is yellow if the message type="warning"
# - the test result is red if the message type="error" or "warning"
#
#
############################################################################################################################################
my $check_nrpe = "/opt/mms/server/bin/check_nrpe";
my $xymonwin = "/opt/mms/server/ext/checkwin/checkwin_nrpe.cfg";
my $XYMONHOME = "/opt/mms/server";
my $XYMON = "$XYMONHOME/bin/xymon";
my $XYMONSERVERIP = "localhost";
my $VERSION = "Xy-checkwinEventlog-2.0.1";
############# Client test ###############
sub check_client {
	$cmd = "$check_nrpe -H $ip -p $port";
	$result = `$cmd`;
	if ($result =~/Connection refused by host/||$result =~/CHECK_NRPE: Socket timeout after.*/||$result =~/Received 0 bytes from daemon.  Check the remote server logs for error messages./||$result =~/UNKNOWN: No handler for that command/) {
		$clientstatus = "red";
	} else {
		$clientstatus = "green";
	}
}
############# Event log check ###############
sub check_log {
if ($clientstatus eq "red") {
	$cmd = "$XYMON localhost \"status $host.msgs clear `date`: NOK The client check failed\n\n<font color=DarkSlateBlue >$VERSION</font>\"";
	system ($cmd);}
else {
	($tag, @log) = split (/;/,$test);
	$line = "";
	$pagecolor = "green";
	$msg="Windows event logs\n";
	foreach $log (@log) {
		if ($log =~/[a-z,A-Z,\",\s]*,[a-z,A-Z]*/) {
		$args = "";
		($logfile, @arg) = split (/,/, $log);
		foreach $arg (@arg) {
#			$arg=~/.*/;
			$arg=~s/^\s+//;
			$args .= "$arg,";
			}
		chop($args);
		$cmd = "$check_nrpe -H $ip -p $port -c CheckEventLog -a file=$logfile MaxWarn=1 MaxCrit=1 \"filter=type IN (warning,error) AND generated > -15m AND source NOT IN ($args)\" truncate=800 unique 'syntax=�Type:%type% Severity:%severity% Source:%source% id:%id% %strings%'";
		}
		else {
			$log =~/([a-z,A-Z,\",\s]*)/;
			$logfile = $1;
			$cmd = "$check_nrpe -H $ip -p $port -c CheckEventLog -a file=$logfile MaxWarn=1 MaxCrit=1 \"filter=type IN (warning,error) AND generated > -15m\" truncate=800 unique 'syntax=�Type:%type% Severity:%severity% Source:%source% id:%id% %strings%'";
		}
	$result = `$cmd`;
#print "$cmd\n";
#print "$result\n";
		if ($result =~/^Eventlog check ok\|[a-z,A-Z,0-9,\',\=,\;]*/){
			$result =~/^Eventlog (check ok)\|([a-z,A-Z,0-9,\',\=,\;]*)/;
			$color = "green";
			$title = "OK";
			$line = "&$color <font color=yellow> $logfile log $1 </font>\n";
			$msg .= $line;
#print "$msg\n";
		} else {
			($eventlog, @event) = split (/�/,$result);
			$events = "";				$pagecolor = "green";
			foreach $event (@event) {
				$event =~ s/, ,//;
				$event =~ s/\R//g;
				$event =~ s/\|'eventlog'/\n eventlog/;
				$event =~ /^Type:([a-z,A-Z]*)([a-z,A-Z,0-9,\s,\',\,,\=,\;,:]*)/;
				$eventtype = $1;
#print "$eventtype ";
					if ($eventtype eq "warning" and $pagecolor ne "red") {
						$color = "yellow";
						$pagecolor = "yellow";
					} elsif ($eventtype eq "error") {
						$color = "red";
						$pagecolor = "red";
					}
#print "$color\n";
				$events .= "$event\n";
				$title = "NOK\n";
				$eventline .= "&nbsp &$color $event \n";
			}
#print "MSG $msg\n";
		}
		if ($pagecolor ne "green"){
			$line .= "&$pagecolor <font color=yellow> $logfile log </font>\n";
			$msg = $line;
			$msg .= $eventline;
		}
	}
	$msg .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
	$cmd = "$XYMON localhost \"status $host.msgs $pagecolor `date` $title\n$msg\"";
	system ($cmd);
}}
############ select test #############
sub check_win {
	($machine, $tests) = split (/#/,$line);
	($host, $ip, $port, $password) = split (/\s+/, $machine);

	$tests =~ s/^\s+//;
	$tests =~ s/\s+$//;

	@tests = split (/\|+/, $tests);

	foreach $test (@tests) {
		switch:  for ($test) {
			if (/^client*/) {check_client; }
			if (/^log*/) { check_log; }
		}
	}
	return TRUE;
}

open (FILE, $xymonwin);
while (<FILE>) {
	$line = $_;
	$line =~ s/^\s+//;
	$line =~ s/\s+$//;


	if ($line ne "") {
		sleep (1);

		my $pid = fork();
		if ($pid) {
			push(@childs, $pid);
		} elsif ($pid == 0) {
			check_win($line);
			exit(0);
		} else {
			die "couldn't fork: $!\n";
		}
	}
}
close (FILE);

foreach (@child) {
	waitpid($_,0);
}
