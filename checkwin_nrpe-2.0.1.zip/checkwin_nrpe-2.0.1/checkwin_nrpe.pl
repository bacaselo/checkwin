#!/usr/bin/perl
###################################################################
# Author: Cameron Seeber
# Modified: by Bart Gillis - Bacaselo
#			in order to work with the more powerfull check_nrpe command.
# Purpose:	This is a script that allows Xymon to pull data from a windows machine. 
# 			BBWin only pushes the data and can not be used on networks that don't allow inbound trafic.
###################################################################
#
# This is a script that allows Xymon to pull data from a windows machine.
# Our network model only allows for connections outbound from our management network so I thought I would spend the time to write this script.
# For it to work you will need to get a copy of check_nrpe on your machine.
# This is the client that is used to speak to nsclient++ that is used in Nagios.
# When you install the Nagios package or port you should find this binary (eg its in the net-mgmt/nagios port on FreeBSD)
# NSClient++ is available at http://trac.nakednuns.org/nscp/downloads
# This script was used against version 0.3.9 but should work with newer versions.
#
# You will need a config file for it to work
# I thought about putting it all in the hosts.cfg file but it just gets to messy, and I wanted to reuse some of the common tags
# The config file should be located in $XYMONHOME/etc/checkwin/checkwin_nrpe.cfg (or you can change it below)
#
# This script forks before starting each client check.  You will also notice a sleep(1) just before the fork.  I found that in speeding up the 
# client queries I was able to affect the monitoring machines network performance and cpu to the point that simple tests like http and the like
# were taking 400-800ms to complete instead of the expected 40ms. So I delayed each test for 1 second.
# This is irrelevant as each test will still start the same time apart as you configure in the tasks.cfg file (say 1 minute) as it will 
# always delay the start of the client test however low it is in the config file.
#
# Please note that this hasn't been tested by anyone but me.
#
# Known Bugs:
# - There is one know bug in the disk check. If the free disk space goes under 1 MB the monitor goes green.
#
# I have to fix these litte bugs if I find some time
#
# VARIABLES
#
# The most of the variables in this script are declared at the top of the script.
# They are all pretty straight forward and where they mirror ones in the xymonserver.cfg file they use the same names
# I thought about bringing in the config file but I thought parsing that whole file for two variables was a little too much effort.
#
# $check_nrpe	 - location of the check_nrpe binary
# $xymonwin		 - location of the checkwin_nrpe file
# $XYMONHOME	 - location of your xymon install
# $XYMON		 - xymon binary
# $XYMONSERVERIP - ip address or hostname of the xymon server
#
#
# CONFIG FILE
#
# Format of the file will be like this
#
# xymonhostname	port	password	#   test [test] ....
#
# xymonhostname	- this is the host that you want the test recorded under. This should match one in the hosts.cfg file
# port		- This is the port that nsclient++ is listening on
# password	- This is the password set in nsclient++
# # 		- This is just a seperator much like in hosts.cfg
# test		- client|cpu|disk|memory|uptime|service|procs|files|bbwin
#================================================================================================
# client
#	This tests the nsclient++ connectivity to the client. Before testing the client we will check if the destination address responds to a fping. 
#		- If fping fails: no further tests will be be executed and all test results will get a clear status.
#		- If fping test is OK but no connection to the client can be accomplished: The client test goes red and all other tests are skipped and get a clear status.
#		- If client test is OK: Client test status is green and the test result shows the NSClient++ version info.
#
#================================================================================================
# cpu[:average[:yellow:red]]	
#	This tests the cpuload on the client. By default it will get the average over the last 5 minutes and trigger yellow at 80% and red at 90%
#	Uses the builtin rrd graphs.
#
#	average - This allows you to set the average sample rate. The lower the number the more likely it is that a warning will be triggered. Value is in minutes. (Default: 5)
#	yellow 	- This is the percentage at which yellow is triggered. (Default: 80)
#	red		- This is the percentage at which red is triggered. (Default: 90) 
# 
#===============================================================================================
# disk[:drive,yellow,red[:drive,yellow,red[:drive,yellow,red]...]] 
#	This tests the drive space on specified physical disks.
#
#	drive	- This is a single letter representing the physical drive on the disk (eg "disk:c")
#	Yellow	- This is the percentage space used or the free space left in MByte at which yellow is triggered. (Default: 80%)
#	Red 	- This is the percentage space used or the free space left in MByte at which red is triggered. (Default: 90%)
#	example: disk:c,80,90:E,950M,800M:f:r,800m,500m
#	The parameters are not case sensitive !!!
#
#================================================================================================
# memory[:yellow:red]
#	This tests the Physical- Virtual(=Commit)- and Page(="Commit - Physical")- memory on the machine. 
#	This script uses the built-in rrd graphs. Virtual->actual, Physical->real, Page->swap
#	Explanation: Commit charge is the maximum amount of memory the current process can commit.
#
#	The tresholds are affected on the �Page� parameter. Only if the Commit charge goes over the total Physical memory we want to be warn.
# 
#	yellow 	- This is the percentage at which yellow is triggered. (Default: 40)
#	red	- This is the percentage at which red is triggered. (Default: 50)
#
#=================================================================================================
# uptime[:yellow:red]
#	This tests the uptime of the machine. By default it will trigger yellow at 10 minutes and red at 5 minutes
#
#	yellow	- Number of minutes within a reboot to display yellow (Default: 10)
#	red		- Number of minutes within a reboot to display red (Default: 5)
#
#==================================================================================================
# service;[servicename,status[;servicename,status[;servicename,status;[automatic:"servicename1":"servicename2":"servicename3":...]]]]
#	servicename:	- The test triggers yellow if the service was not found on the server.
#	status:			- requested status of the service. The test triggers red if the actual status of a windows service is not equal to the requested one. (Default: started)
#	automatic:"servicename1":"servicename2":"servicename3":		
#					- if you specify the word "automatic", all services that are defined as autostart triggers red if they are stopped with exclusion of the services specified after the word "automatic".
#					- the excluded services must be preceded by a ":" character.
#
#===================================================================================================
# procs;[process,amount[;process,amount[;process,amount]...]]
#	process:	- Name of the process. The test triggers red if the process is not running on the server.
#	amount:		- The test triggers red if the amount of the processes is lower than the specified value. (Default: 1). 
#
#====================================================================================================
# files:[file;/path:"E:\IISLogs\W3SVC481920888" /searchdepth:1 /selage:ignore /warning:10 /critical:15[;/path:"E:\IISLogs\W3SVC481920888" /searchdepth:1 /selage:ignore /warning:10 /critical:15]]
#
# args:
#
# warning: threshold warning 
#    alert if x...
#             10	         < 0 or > 10, (outside the range of {0 .. 10})
#             10:	         < 10, (outside {10 .. 8})
#             ~:10	       > 10, (outside the range of {-8 .. 10})
#             10:20	       < 10 or > 20, (outside the range of {10 .. 20})
#             @10:20	     >= 10 and <= 20, (inside the range of {10 .. 20})
# critical: threshold critical 
# namefilter: regular expressionon on which files have to match
# age: files have to be older/newer (see selage) than age
#    e.g.: 5d: 5 days, 4h: 4 hours, 10n: 10 Minutes, 90s: 90 seconds   
# selage: older/newer/hour/ignore
#    older/newer: count only files if the are older/newer
#    hour: alert if file is not written until hour
#    ignore: count files independent of their age 
# searchdepth: search down x subdirs (searchdepth:1 - do not go down in directory hierarchy)
# seldat: modified/created
#    modified: date, when file was written
#    created: date, when file was created
# size: if file is smaller than given size give a warning
# expectmatch: if less than expectmatch files correspond to namefilter give a warning
# weekdays: 
#    if selage:hour files have to be written only on weekdays (1:sunday, 2:monday, ...)
#    if selage:newer or selage:older and the timeunit of age is d (days), we add as many days to age as the last weekday is back
#    e.g.: weekdays:23456 files are written on Monday, Tuesday, Wednesday, Thursday, Friday
#
# Remark: The separator between differend files checks is ";" 
#	   arguments start with the "/" character (example /path:)
#
#=============================================================================
# bbwin;[script:testname[;script:testname...]]
#	script:		- Name of the batch file that will call the external bbwin script. (example: "cscript //nologo <filename>.vbs")
#	testname:	- Xymon test column name
#	delay:		- number of second that the script may run. If not specified the default value will be used (default = 10) 
#
# This plugin will read the text files that are stored in the folder c:\program files\NSClient++\scripts on the Windows server.
# In order to work you must also install the batch files "BBWinRun.bat and BBWinResult.bat" in that folder.
# remark: If you don't specify the script argument this plugin will only read the contenet of the file with the same name as the argument.
#         This makes it possible to create scripts with different result files that may be upoaded to multiple columns.
#example: bbwin;[script:testname1:delay[;testname1[;testname3...]]]
#
#
############################################################################################################################################
my $fping = "/usr/sbin/fping";					# Path and options for the ping program.
my $check_nrpe = "/opt/mms/server/bin/check_nrpe";
my $xymonwin = "/opt/mms/server/ext/checkwin/checkwin_nrpe.cfg";
my $XYMONHOME = "/opt/mms/server";
my $XYMON = "$XYMONHOME/bin/xymon";
my $XYMONSERVERIP = "localhost";
my $VERSION = "Xy-checkwin-2.0.1";
############# Client test ###############
sub check_client {
	$cmd = "$fping $ip";
	$result = `$cmd`;
	if ($result =~/is unreachable/) {
		$cmd = "$XYMON localhost \"status $host.client clear `date`: NOK ping check to $ip failed\n\n<font color=DarkSlateBlue >$VERSION</font>\"";
		system ($cmd);
		$fpingstatus = "red";
	}
	else{
		$fpingstatus = "green";
		$cmd = "$check_nrpe -H $ip -p $port";
		$result = `$cmd`;
	if ($result =~/Connection refused by host/||$result =~/CHECK_NRPE: Socket timeout after.*/||$result =~/Received 0 bytes from daemon.  Check the remote server logs for error messages./||$result =~/UNKNOWN: No handler for that command/) {
		$result .= "\n <font color=DarkSlateBlue >$VERSION</font>";
		$cmd = "$XYMON localhost \"status $host.client red `date`: NOK\n\n$result\"";
		system ($cmd);
		$clientstatus = "red";
	} else {
		$result .= "\n <font color=DarkSlateBlue >$VERSION</font>";
		$cmd = "$XYMON localhost \"status $host.client green `date`: OK\n\n$result\"";
		system ($cmd);
	}}
}
############ uptime #############
sub check_uptime {
if ($clientstatus||$fpingstatus eq "red") {
	$cmd = "$XYMON localhost \"status $host.uptime clear `date`: NOK The client check failed\n\n <font color=DarkSlateBlue >$VERSION</font>\"";
	system ($cmd);}
else {
	if ($test =~ /^uptime:+/) {
		$test =~ /^uptime:([0-9]*):([0-9]*)/;
		$yellow = $1;
		$red = $2;
	} else {
		$yellow = 10;
		$red = 5;
	}
	$yellow = $yellow*60;
	$red = $red*60;
	$cmd = "$check_nrpe -H $ip -p $port -c CheckUpTime -a MinWarn=1s MinCrit=2s";
	$upresult = `$cmd`;
	if ($upresult =~/Connection refused by host/||$upresult =~/Received 0 bytes from daemon.  Check the remote server logs for error messages./||$upresult =~/UNKNOWN: No handler for that command/) {
	$upresult .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
	$cmd = "$XYMON localhost \"status $host.uptime red `date`: NOK\n\n$upresult\"";
		system ($cmd);
	} else {
		$upresult =~ /^O.*\|'uptime'=([0-9]*);([0-9]*);([0-9]*).*/;
		$time = $1/1000;
		$days = $time/(24*60*60);		
		$updays = sprintf("%.0f", $days);
		$hour=($time/(60*60))%24;
		$min=($time/60)%60;
		$sec=$time%60;
		$upresult = "uptime: $updays day(s) $hour Hour(s) $min Minute(s)";
		if ($time < $red) {
			$upresult .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
			$cmd = "$XYMON localhost \"status $host.uptime red `date`: Recently rebooted\nWarning levels\: yellow\:$yellow sec red\:$red sec\n\n$upresult\"";
		} elsif ($time < $yellow) {
			$upresult .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
			$cmd = "$XYMON localhost \"status $host.uptime yellow `date`: Recently rebooted\nWarning levels\: yellow\:$yellow sec red\:$red sec\n\n$upresult\"";
		} else {
			$upresult .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
			$cmd = "$XYMON localhost \"status $host.uptime green `date`: OK\nWarning levels\: yellow\:$yellow sec red\:$red sec\n\n$upresult\"";
		}
		system ($cmd);
	}}
}
############ cpu test #############
sub check_cpu {
if ($clientstatus||$fpingstatus eq "red") {
	$cmd = "$XYMON localhost \"status $host.cpu clear `date`: NOK The client check failed\n\n<font color=DarkSlateBlue >$VERSION</font>\"";
	system ($cmd);}
else {
	if ($test =~ m/^cpu:+/) {
		$test =~ /cpu:([0-9]*):([0-9]*)/;
		$yellow = $1;
		$red = $2;
	} else {
		$yellow = 90;
		$red = 100;
	}
	$cmd0 = "$check_nrpe -H $ip -p $port -c CheckUpTime -a MinWarn=1s MinCrit=2s";
	$upresult = `$cmd0`;
	if ($upresult =~/Connection refused by host/||$upresult =~/Received 0 bytes from daemon.  Check the remote server logs for error messages./||$upresult =~/UNKNOWN: No handler for that command/) {
	$upresult .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
	$cmd0 = "$XYMON localhost \"status $host.cpu red `date`: NOK\n\n$upresult\"";
		system ($cmd0);
	} else {
		$upresult =~ /^O.*\|'uptime'=([0-9]*);([0-9]*);([0-9]*).*/;
		$time = $1/1000;
		$days = $time/(24*60*60);
		$updays = sprintf("%.0f", $days);

		$cmd = "check_nrpe -H $ip -p $port -c CheckCPU -a warn=100 crit=100 time=15s";
		$result = `$cmd`;
			if ($result =~/Connection refused by host/||$result =~/Received 0 bytes from daemon.  Check the remote server logs for error messages./||$result =~/UNKNOWN: No handler for that command/) {
			$result .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
			$cmd = "$XYMON localhost \"status $host.cpu red `date`: NOK\n\n$result\"";
				system ($cmd);
			} elsif ($result =~ /^OK CPU Load ok.\|'([0-9]*)s'=([0-9]*)%;([0-9]*);([0-9]*)/) {
				$result =~ /^OK CPU Load ok.\|'([0-9]*)s'=([0-9]*)%;([0-9]*);([0-9]*)/;
				$load = $2;
				$cmd1 = "$check_nrpe -H $ip -p $port -c procs";
				$procs =  `$cmd1`;
					if ($procs =~/Input Error: .*/) {
						$procs .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
						$cmd1 = "$XYMON localhost \"status $host.cpu red `date`: NOK\n\n$procs\"";
						system ($cmd1);
					} else {		
						$procs =~ /^([0-9]*)/;
						$procsresult = $1;
						$cmd2 = "$check_nrpe -H $ip -p $port -c user_number";
						$usersresult = `$cmd2`;
							if ($usersresult =~/Input Error: .*/) {
								$usersresult .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
								$cmd2 = "$XYMON localhost \"status $host.cpu red `date`: NOK\n\n$usersresult\"";
								system ($cmd2);
							} else {		
								$usersresult =~ /^Sessions accepted                  ([0-9]*)/;
								$usersresult = "$1";
								if ($load >= $red) {
									$color = "red";
								} elsif ($load >= $yellow) {
									$color = "yellow";
								} else {
									$color = "green";
								}
								$procs .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
								$cmd = "$XYMON localhost \"status $host.cpu $color `date` up: $updays days, $usersresult users, $procsresult procs, load=$load%\nWarning levels\: yellow\:$yellow red\:$red\n\n$result\n$procs\"";
								system ($cmd);
							}
					}
			} else {
				$cmd = "$XYMON localhost \"status $host.cpu green `date`: INFO\n\n &yellow Informational: Script didn't picked up any process value\nno action required\n\n <font color=DarkSlateBlue >$VERSION</font>\"";
				system ($cmd);
			}

	}}
}
############# disk test ###############
sub check_disk {
if ($clientstatus||$fpingstatus eq "red") {
	$cmd = "$XYMON localhost \"status $host.disk clear `date`: NOK The client check failed\n\n$VERSION\"";
	system ($cmd);}
else {
	($tag, @drives) = split (/:/,$test);
	$line = "";
	$pagecolor = "green";
	foreach $drive (@drives) {
		if ($drive =~ /[a-z,A-Z]*,[0-9]*[Mm],[0-9]*[Mm]/) {
			$drive =~ /([a-z,A-Z]*),([0-9]*)[Mm],([0-9]*)[Mm]/;
			$drive = $1;
			$yellow = $2;
			$red = $3;
			$treshold = "expl";
		} elsif ($drive =~ /[a-z,A-Z]*,[0-9]*,[0-9]*/) {
			$drive =~ /([a-z,A-Z]*),([0-9]*),([0-9]*)/;
			$drive = $1;
			$yellow = $2;
			$red = $3;
			$treshold = "%";
		} else {
			$yellow = 80;
			$red = 90;
			$treshold = "default";
		}
$ucdrive = uc($drive);
	$cmd = "$check_nrpe -H $ip -p $port -c CheckDriveSize -a ShowAll MaxWarn=1M MaxCrit=2M Drive=$ucdrive:";
	$result = `$cmd`;
	if ($result =~/CRITICAL: $ucdrive:/) {
		$result =~ /^.* ([0-9]*.[0-9]*)([KMGT]) - Used: ([0-9]*.[0-9]*)([KMGT]) \(([0-9]*)\%\) - Free: ([0-9]*.[0-9]*)([KMGT]) \(([0-9]*)\%\) > critical\|'[A-Z,a-z]: \%'=[0-9]*\%;[0-9]*;[0-9]*.* '[A-Z,a-z]:\'=([0-9]*.[0-9]*)[KMGT].*;[0-9]*;[0-9]*;[0-9]*;([0-9]*.[0-9]*).*/;
		if ($treshold ne "expl") {
			$free = ($10-$9)/1,024;
			if ($5 >= $red) {
				$color = "red";
				$title = ": Critcal";
				$pagecolor = "red";
			} elsif ($5 >= $yellow) {
				$color = "yellow";
				if ($pagecolor eq "red"){
					$title = "CRITICAL";
				} else {
					$pagecolor = "yellow";
					$title = "WARNING";
				}
			} else {
				$color = "green";
				if ($pagecolor eq "red"){
					$title = "CRITICAL";
				} elsif ($pagecolor eq "yellow"){
					$title = "WARNING";
				} else {
					$title = ": OK";
				}
			}
		$line .= "$ucdrive 		$1$2 		$3$4 		$6$7 		$5% 		&$color /$ucdrive  		yellow\:$yellow\% red\:$red\%\n";
		} else {
			$free = ($10-$9)/1,024;
			if ($free <= $red) {
				$color = "red";
				$title = ": Critcal";
				$pagecolor = "red";
			} elsif ($free <= $yellow) {
				$color = "yellow";
				if ($pagecolor eq "red"){
					$title = "ERROR";
				} else {
					$pagecolor = "yellow";
					$title = "WARNING";
				}			
			} else {
				$color = "green";
				if ($pagecolor eq "red"){
					$title = "ERROR";
				} elsif ($pagecolor eq "yellow"){
					$title = "WARNING";
				} else {
					$title = ": OK";
				}
			}
		$line .= "$ucdrive 		$1$2 		$3$4 		$6$7 		$5% 		&$color /$ucdrive  		yellow\:$yellow\M red\:$red\M\n";
		}
	} else {
			$color = "red";
			$pagecolor = "red";
			$title = " does not exist\n";
			$line .= "&$color $drive does not exist $result\n";
		}
	}
	$msg  = "Filesystem	Size    	Used    	Avail    	Capacity	Mounted		Warning levels\n";
	$msg .= $line;
	$msg .= "\n\n $VERSION";
	$cmd = "$XYMON localhost \"status $host.disk $pagecolor `date`: Filesystems $title\n$msg\"";
	system ($cmd);

}}
############# memory test ###############
sub check_memory {
if ($clientstatus||$fpingstatus eq "red") {
	$cmd = "$XYMON localhost \"status $host.memory clear `date`: NOK The client check failed\n\n<font color=DarkSlateBlue >$VERSION</font>\"";
	system ($cmd);}
else {
	$pagecolor = "green";
	$cmd = "$check_nrpe -H $ip -p $port -c CheckMEM -a MaxWarn=100% MaxCrit=100% ShowAll type=physical type=page";
	$result = `$cmd`;
	if ($result =~/Connection refused by host/||$result =~/Received 0 bytes from daemon.  Check the remote server logs for error messages./||$result =~/UNKNOWN: No handler for that command/) {
	$result .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
	$cmd = "$XYMON localhost \"status $host.memory red `date`: NOK\n\n$result\"";
		system ($cmd);
	} else {
		if ($test =~ m/^memory:+/) {
			$test =~ /memory:([0-9]*):([0-9]*)/;
			$yellow = $1;
			$red = $2;
		} else {
			$yellow = 40;
			$red = 50;
		}
		$result =~ /^O.*\|'physical memory %'=([0-9]*.[0-9]*)%;([0-9]*.[0-9]*);([0-9]*.[0-9]*).* 'physical memory'=([0-9]*.[0-9]*)([MG]).*;([0-9]*.[0-9]*);([0-9]*.[0-9]*);([0-9]*.[0-9]*);([0-9]*.[0-9]*).* 'page file %'=([0-9]*.[0-9]*)%;([0-9]*.[0-9]*);([0-9]*.[0-9]*).* 'page file'=([0-9]*.[0-9]*)([MG]).*;([0-9]*.[0-9]*);([0-9]*.[0-9]*)\;([0-9]*.[0-9]*);([0-9]*.[0-9]*).*/;
		$commit = $13;
		$totcommit = $15;
			if (($5 ne $14) and ($5 eq "G")) {
				$commit = $13/1000;
				$totcommit = $15/1000;
			} 
			elsif ($5 ne $14) {
				$commit = $13*1000;
				$totcommit = $15*1000;
			}
			$totswap = $totcommit-$6;
			$swap = $commit - $4;
			$swap = sprintf("%.2f", $swap);
			if ($swap <= 0) {
				$swap = 0.01;			
			}
			$swappct = int(($swap/$totswap)*100+0.5);
		if ($swappct >= $red) {
			$color = "red";
			$pagecolor = "red";
			$title = ": Memory Critical";
		} elsif ($swappct >= $yellow) {
			$color = "yellow";
			if ($pagecolor eq "red") {
				$pagecolor = "red";
			} else {
				$pagecolor = "yellow";
			}
			$title = ": Memory Warning";
		} else {
			$color = "green";
			$title = ": Memory OK";
		}
				if ($10 >= 100) {
			$comcolor = "red";
#			$title = ": Memory Critical";
		} elsif ($10 >= 98) {
			$comcolor = "yellow";
#			$title = ": Memory Warning";
		} else {
			$comcolor = "green";
#			$title = ": Memory OK";
		}
		$msg  = "$title\nWarning levels\: yellow\:$yellow red\:$red\n\n";
		$msg .= "<table border=0>";
		$msg .= "<tr align=right><td width=100>Memory:</td><td width=100>Used</td><td width=100>Total</td><td width=100>Pctg</td></tr>";
		$msg .= "<tr align=right><td>&green Physical:</td><td>$4$5</td><td>$6$5</td><td>$1%</td></tr>";
		$msg .= "<tr align=right><td>&$comcolor Virtual: </td><td>$13$14</td><td>$15$14</td><td>$10%</td></tr>";
		$msg .= "<tr align=right><td>&$color Page:  &nbsp;&nbsp</td><td>$swap$5</td><td>$totswap$5</td><td>$swappct%</td></tr>";
		$msg .= "</table>\n\n";
			$cmd1 = "$check_nrpe -H $ip -p $port -c memuse";
		$msg .= "Top 5 of jobs with highest memory load\n";
			$msg .=  `$cmd1`;
		$msg .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
		$cmd = "$XYMON localhost \"status $host.memory $pagecolor `date`$msg\"";
		system ($cmd);
	}}
}
############# service test ###############
sub check_service {
if ($clientstatus||$fpingstatus eq "red") {
	$cmd = "$XYMON localhost \"status $host.svcs clear `date`: NOK The client check failed\n\n<font color=DarkSlateBlue >$VERSION</font>\"";
	system ($cmd);}
else {
	($tag, @service) = split (/;/,$test);
	$line = "";
	$pagecolor = "green";
	foreach $service (@service) {
		if ($service =~/[0-9,a-z,A-Z,\",\s,\:,\(,\),\_,\.,\$,\\,\-]*=[0-9,\-,a-z,A-Z,\",\s,\:,\(,\),\_,\.,\$,\\]*/){
			$service =~ s/\$/\\\$/g;
			$service =~ /([0-9,\-,a-z,A-Z,\",\s,\:,\(,\),\_,\.,\$,\\]*)=([0-9,\-,a-z,A-Z,\",\s,\:,\(,\),\_,\.,\$,\\]*)/;
			$service = $1;
			$reqstat = $2;
			$servcheck = "$1=$2";
			$cmd = "$check_nrpe -H $ip -p $port -c CheckServiceState -a ShowAll $servcheck";
		} elsif ($service =~/automatic[0-9,\-,a-z,A-Z,\",\s,\:,\(,\),\_,\.,\$,\\]*/) {
		$args = "";
		($argument, @arg) = split (/:/, $service);
		foreach $arg (@arg) {
			$arg=~/.*/;
			$args .= "exclude=$arg ";
			}
		$cmd = "$check_nrpe -H $ip -p $port -c CheckServiceState -a CheckAll $args";
		}		
		else {
			$service =~ s/\$/\\\$/g;
#	print "$service\n";
			$service =~/([0-9,\-,a-z,A-Z,\",\s,\:,\(,\),\_,\.,\$,\\]*)/;
			$service = $1;
			$reqstat = "started";
			$servcheck = $1;
			$cmd = "$check_nrpe -H $ip -p $port -c CheckServiceState -a ShowAll $servcheck";
		}
	$result = `$cmd`;
#	print "$cmd\n";
		if ($result =~/^CRITICAL: [0-9,\-,a-z,A-Z,\s,\:,\(,\),\_,\.,\$,\\]*: not found/){
			$result =~ s/\$/\\\$/g;
			$result =~/^CRITICAL: ([0-9,\-,a-z,A-Z,\s,\:,\(,\),\_,\.,\$,\\]*): not found/;
			if ($pagecolor eq "red") {
				$pagecolor = "red";
			} else {
				$pagecolor = "yellow";
			}
			$color = "yellow";
			$title = "Service does not exist\n";
			$line .= "&$color service \'$1\' not found\n";
		} elsif ($result =~/^OK: [0-9,\-,a-z,A-Z,\s,\:,\(,\),\_,\.,\$,\\]*: not found/){
			$result =~ s/\$/\\\$/g;
			$result =~/^OK: ([0-9,\-,a-z,A-Z,\s,\:,\(,\),\_,\.,\$,\\]*): not found/;
			if ($pagecolor eq "red") {
				$pagecolor = "red";
			} else {
				$pagecolor = "yellow";
			}
			$color = "yellow";
			$title = "Service does not exist\n";
			$line .= "&$color service \'$1\' not found\n";
		} elsif ($result =~/OK: [0-9,\-,a-z,A-Z,\s,\:,\(,\),\_,\.,\$,\\]*: [a-z,A-Z]*/) {
			$result =~ s/\$/\\\$/g;
			$result =~/^OK: ([0-9,\-,a-z,A-Z,\s,\:,\(,\),\_,\.,\$,\\]*): ([a-z,A-Z]*)/;
			$color = "green";
			$title = "OK";
			$line .= "&$color $1 $2\n";
		} elsif ($result =~/OK: All services are in their appropriate state./) {
			$result =~/([0-9,\-,a-z,A-Z,\s,\:,\(,\),\_,\.,\$,\\]*)/;
			$color = "green";
			$title = "OK";
			$line .= "&$color $1 $2\n";
		} else {
			$result =~ s/\$/\\\$/g;
			$result =~/^CRITICAL: ([0-9,\-,a-z,A-Z,\s,\:,\(,\),\_,\.,\$,\\]*): ([a-z,A-Z]*)/;
			$color = "red";
			$pagecolor = "red";
			$title = "NOK\n";
			$line .= "&$color $result &nbsp but \'$reqstat\' was requested\n";
		}
	}
	$msg  = "Service	Status\n";
	$msg .= $line;
	$msg .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
	$cmd = "$XYMON localhost \"status $host.svcs $pagecolor `date` $title\n$msg\"";
	system ($cmd);
}}
############# process test ###############
sub check_procs {
if ($clientstatus||$fpingstatus eq "red") {
	$cmd = "$XYMON localhost \"status $host.procs clear `date`: NOK The client check failed\n\n<font color=DarkSlateBlue >$VERSION</font>\"";
	system ($cmd);}
else {
	($tag, @procs) = split (/;/,$test);
	$line = "";
	$pagecolor = "green";
	foreach $proc (@procs) {
		if ($proc =~/[a-z,A-Z,\",\.,\(,\),\s,\+,_]*,[0-9]*/){
			$proc =~ /([a-z,A-Z,\",\.,\(,\),\s,\+,_]*),([0-9]*)/;
			$proccheck = $1;
			$reqnumber = $2;
		} else {
			$proc =~/([a-z,A-Z,\",\s,\.,\(,\),\+,_]*)/;
			$proc = $1;
			$reqstat = "started";
			$proccheck = $1;
		}
	$cmd = "$check_nrpe -H $ip -p $port -c CheckProcState -a ShowAll $proccheck";
	$result = `$cmd`;

		if ($result =~/^OK: [a-z,A-Z,\s,\.,\(,\),\+,_]*: [0-9]*/) {
			$result =~/^OK: ([a-z,A-Z,\s,\.,\(,\),\+,_]*): ([0-9]*)/;
			$number = $2;
			if ($number < $reqnumber) {
				$color = "red";
				$pagecolor = "red";
				$title = "NOK\n";
				$line .= "&$color CRITICAL:  $2 instance(s) of $1 are running but \'$reqnumber\' required\n";
			} else {
				$color = "green";
				if ($title eq "NOK\n") {
					$title = "NOK\n";
				} else {
				$title = "OK";
				}
				$line .= "&$color OK: $1: $2 proc(s) running\n";
			}
		} else {
			$result =~/^CRITICAL: ([a-z,A-Z,\s,\.,\(,\),\+,_]*): ([a-z,A-Z]*)/;
			$color = "red";
			$pagecolor = "red";
			$title = "NOK\n";
			$line .= "&$color $result";
		}
	}
	$msg  = "Process	Status\n";
	$msg .= $line;
	$msg .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
	$cmd = "$XYMON localhost \"status $host.procs $pagecolor `date` $title\n$msg\"";
	system ($cmd);

}}
############ Files test #############
sub check_files {
if ($clientstatus||$fpingstatus eq "red") {
	$cmd = "$XYMON localhost \"status $host.files clear `date`: NOK The client check failed\n\n<font color=DarkSlateBlue >$VERSION</font>\"";
	system ($cmd);}
else {
	($tag, @file) = split (/;/,$test);
	$line = "";
	$pagecolor = "green";
	foreach $file (@file) {
		$args = "";
		($argument, @arg) = split (/\//, $file);
		foreach $arg (@arg) {
			$arg=~s/^\s+//;
			$args .= "/$arg";
			}
		$cmd = "$check_nrpe -H $ip -p $port -c check_files -a $args";
#	print "$cmd\n";
	$result = `$cmd`;
		if ($result =~/^CRITICAL/) {
			$pagecolor = "red";
			$title = "ERROR";
			$color = "red";
			$line .= "&$color $result";
		} elsif ($result =~/^WARNING/||$result =~/.*Path not found.*/) {
			$color = "yellow";
			if ($pagecolor eq "red"){
				$line .= "&$color $result";
			} else {
				$pagecolor = "yellow";
				$title = "WARNING";
				$line .= "&$color $result";
			}
		} else {
			$color = "green";
			if ($pagecolor eq "red"){
				$line .= "&$color $result";
				$title = "ERROR";
			} elsif ($pagecolor eq "yellow"){
				$line .= "&$color $result";
				$title = "WARNING";
			} else {
				$title = "OK";
				$line .= "&$color $result";
			}
		}
	}
	$msg  = "File Check\n";
	$msg .= $line;
	$msg .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
	$cmd = "$XYMON localhost \"status $host.files $pagecolor `date` $title\n$msg\"";
	system ($cmd);
}}
############ BBWin external Script test #############
sub check_bbwin {
	($tag, @bbwintest) = split (/;/,$test);
	$line = "";
	$pagecolor = "green";
	$script = "";
	$testname = "";
	$bbwintest = "";
	foreach $bbwintest (@bbwintest) {
	if ($bbwintest =~ /[a-z,A-Z,0-9]*\s*:\s*[a-z,A-Z,0-9]*\s*:\s*[0-9]*/){
		$bbwintest =~ /([a-z,A-Z,0-9]*)\s*:\s*([a-z,A-Z,0-9]*)\s*:\s*([0-9]*)/;
		$script = $1;
		$testname = $2;
		$delay = $3;
	} elsif ($bbwintest =~ /[a-z,A-Z,0-9]*\s*:\s*[a-z,A-Z,0-9]*/){
		$bbwintest =~ /([a-z,A-Z,0-9]*)\s*:\s*([a-z,A-Z,0-9]*)/;
		$script = $1;
		$testname = $2;
		$delay = 10;
	} elsif ($bbwintest =~ /([a-z,A-Z,0-9]*)/){
		$bbwintest =~ /([a-z,A-Z,0-9]*)/;
		$testname = $1;
	} else {
		$script = "";
		$testname = "";
	}
if ($clientstatus||$fpingstatus eq "red") {
	$cmd = "$XYMON localhost \"status $host.$testname clear `date`: NOK The client check failed\n\n<font color=DarkSlateBlue >$VERSION</font>\"";
	system ($cmd);}
else {
	if ($bbwintest =~ /[a-z,A-Z,0-9]*\s*:\s*[a-z,A-Z,0-9]*.*/){
		$cmd = "$check_nrpe -H $ip -p $port -t $delay -c BBWin -a $script $testname";
#print "$cmd\n";
		$result = `$cmd`;
		@word = ($result =~ /(\w+)/g);
		$pagecolor = @word[0];
	} else {
		$cmd = "$check_nrpe -H $ip -p $port -c BBWinget -a $testname";
		$result = `$cmd`;
		@word = ($result =~ /(\w+)/g);
		$pagecolor = @word[0];
	}
	if ($result =~/Connection refused by host/||$result =~/Received 0 bytes from daemon.  Check the remote server logs for error messages./||$result =~/UNKNOWN: No handler for that command/) {
		$result .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
		$cmd = "$XYMON localhost \"status $host.$testname red `date`: NOK\n\n$result\"";
		system ($cmd);
	} elsif ($result =~/Access is denied./||$result=~/The system cannot find the file specified./) {
		$result .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
		$cmd = "$XYMON localhost \"status $host.$testname clear `date`: NOK\n\n$result\"";
		system ($cmd);
	} else {
		$result =~ s/^\s+//;
		$result =~ s/\s+$//;	
		@rslt = split (/\n+/, $result);
		shift @rslt;
		$result = "";
		foreach $rslt (@rslt) {
				$result .= $rslt."\n";
		}
		$result .= "\n\n <font color=DarkSlateBlue >$VERSION</font>";
		$cmd = "$XYMON localhost \"status $host.$testname $pagecolor `date`\n$result\"";
		system ($cmd);
	}}
}}
############ select test #############
sub check_win {
	($machine, $tests) = split (/#/,$line);
	($host, $ip, $port, $password) = split (/\s+/, $machine);

	$tests =~ s/^\s+//;
	$tests =~ s/\s+$//;

	@tests = split (/\|+/, $tests);

	foreach $test (@tests) {
		switch:  for ($test) {
			if (/^client*/) {check_client; }
			if (/^cpu*/) { check_cpu; }
			if (/^disk*/) { check_disk; }
			if (/^memory*/) { check_memory; }
			if (/^uptime*/) { check_uptime; } 
			if (/^service*/) { check_service; }
			if (/^procs*/) { check_procs; }
			if (/^file*/) { check_files; }
			if (/^bbwin*/) { check_bbwin; }
		}
	}
	return TRUE;
}

open (FILE, $xymonwin);
while (<FILE>) {
	$line = $_;
	$line =~ s/^\s+//;
	$line =~ s/\s+$//;
	if ($line ne "") {
		sleep (1);
		my $pid = fork();
		if ($pid) {
			push(@childs, $pid);
		} elsif ($pid == 0) {
			check_win($line);
			exit(0);
		} else {
			die "couldn't fork: $!\n";
		}
	}
}
close (FILE);

foreach (@child) {
	waitpid($_,0);
}
